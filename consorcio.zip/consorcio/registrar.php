<?php

include("con_db.php");

if (isset($_POST['register'])) {
    if (strlen($_POST['name']) >= 1 && strlen($_POST['password']) >= 1) {
        $name = trim($_POST['name']);
        $password = trim($_POST['password']);
        $email = trim($_POST['email']);
        $consulta = "INSERT INTO usuario(usuario, clave, cor) VALUES ('$name','$password','$email')";
        $resultado = mysqli_query($conex,$consulta);
        if ($resultado) {
            ?>
            <h3>Inscrito correctamente</h3>
            <?php
        } else {
            ?>
            <h3>ocurrio un error</h3>
            <?php
        }
    } else {
        ?>
        <h3>Complete los campos</h3>
        <?php
    }
}

?>