<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <script src="js/bootstrap.min.js"></script>
    <title>SIATMEDIA</title>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-4">

            </div>
            <div class="col-md-4">
                <img src="img/siatmedia_logo.png" class="img-responsive" alt="siatmedia">
                <h2>Aplicacion Consorcio</h2>
						<h3>exclusivo para Siatmedia</h3>
						<p>Ingrese a la plataforma de negocios</p>
                    </div>
                    <div class="col-md-4">

                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4">

                    </div>
                    <div class="col-md-4">
                        <h3><center>REGISTRO DE USUARIOS</center></h3>
                        <br>
                        <form method="post">
                            <div class="form-group">
                        <input type="text" name="name" placeholder="Usuario" class="form-control"/><br>
                        <input type="password" name="password" placeholder="Contraseña" class="form-control"><br>
                        <input type="email" name="email" placeholder="Email" class="form-control"><br>
                        <footer>
                            <center>
                                 <input type="submit" name="register" class="btn btn-primary">
                                <a href="iniciar.php" class="btn btn-link"><p>Iniciar sesion</p></a>
                            </center>
                        </footer>
                        </div>
                        </form>
                        </div>
                        <div class="col-md-4">
                        
                        </div>
                    </div>
                </div>
    <?php
    include("registrar.php");
    ?>   
</body>
</html>